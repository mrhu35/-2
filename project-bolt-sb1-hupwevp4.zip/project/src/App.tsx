import React from 'react';
import { Navbar } from './components/Navbar';
import { useThemeStore } from './store/theme';
import { Play, Star, Clock } from 'lucide-react';

function App() {
  const { theme } = useThemeStore();

  return (
    <div className={theme}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Navbar />
        <main className="pt-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          {/* Featured Section */}
          <section className="mb-12">
            <div className="relative h-[60vh] rounded-xl overflow-hidden">
              <img
                src="https://source.unsplash.com/random/1920x1080?movie"
                alt="Featured movie"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end">
                <div className="p-8">
                  <h2 className="text-4xl font-bold text-white mb-4">Featured Title</h2>
                  <p className="text-gray-200 mb-6 max-w-2xl">
                    Watch the latest blockbuster movies and TV shows with high-quality Arabic dubbing and subtitles.
                  </p>
                  <div className="flex space-x-4">
                    <button className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center space-x-2">
                      <Play className="h-5 w-5" />
                      <span>Watch Now</span>
                    </button>
                    <button className="px-6 py-3 bg-gray-800/80 hover:bg-gray-700 text-white rounded-lg">
                      More Info
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Categories */}
          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-6">Popular Categories</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {['Action', 'Drama', 'Comedy', 'Horror', 'Thriller', 'Romance'].map((category) => (
                <button
                  key={category}
                  className="p-4 bg-white dark:bg-gray-800 rounded-lg hover:bg-purple-50 dark:hover:bg-gray-700 transition-colors"
                >
                  {category}
                </button>
              ))}
            </div>
          </section>

          {/* Content Grid */}
          <section>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Trending Now</h2>
              <button className="text-purple-600 dark:text-purple-400 hover:underline">View All</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden group hover:ring-2 hover:ring-purple-500 transition-all"
                >
                  <div className="relative">
                    <img
                      src={`https://source.unsplash.com/random/400x225?movie&sig=${i}`}
                      alt="Movie cover"
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button className="p-3 bg-purple-600 rounded-full">
                        <Play className="h-6 w-6 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2">Movie Title {i + 1}</h3>
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center space-x-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span>4.5</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4" />
                        <span>2h 15m</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}

export default App;