import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useThemeStore } from '../store/theme';
import { cn } from '../lib/utils';

export function ThemeToggle() {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <button
      onClick={toggleTheme}
      className={cn(
        'p-2 rounded-lg transition-colors',
        theme === 'dark' 
          ? 'bg-gray-800 text-yellow-500 hover:bg-gray-700' 
          : 'bg-gray-200 text-gray-900 hover:bg-gray-300'
      )}
    >
      {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
}