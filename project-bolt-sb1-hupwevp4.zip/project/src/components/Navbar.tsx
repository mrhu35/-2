import React from 'react';
import { Search, Bell, BookmarkPlus, User, Menu, Download } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

export function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white dark:bg-gray-900 shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <button className="lg:hidden p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800">
              <Menu className="h-6 w-6 text-gray-600 dark:text-gray-300" />
            </button>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Sinmana
            </h1>
          </div>

          <div className="hidden md:flex space-x-4 flex-1 max-w-xl mx-8">
            <input
              type="text"
              placeholder="Search movies, TV shows, actors..."
              className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 
                       text-gray-900 dark:text-gray-100 focus:outline-none
                       focus:ring-2 focus:ring-purple-500"
            />
            <button className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors">
              Search
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800 relative">
              <Bell className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
            </button>
            <button className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800">
              <Download className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            </button>
            <button className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800">
              <BookmarkPlus className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            </button>
            <ThemeToggle />
            <button className="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800">
              <User className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              <span className="hidden sm:inline text-gray-600 dark:text-gray-300">Account</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}